from flask import Flask, render_template, request, jsonify
import os
import google.generativeai as genai
from dotenv import load_dotenv
import json

# Load environment variables
load_dotenv()

app = Flask(__name__)

# Configure Google AI
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

# Initialize generation configuration
generation_config = {
    "temperature": 1.9,
    "top_p": 0.95,
    "top_k": 64,
    "max_output_tokens": 8192,
}

# Initialize the model with fashion-specific instructions
model = genai.GenerativeModel(
    model_name="gemini-1.5-pro",
    generation_config=generation_config,
    system_instruction="""
    You are a fashion bot. You will only respond to questions related to fashion tips and fashion advice.
    Keep your answers concise, with a maximum of 50 words.
    Remove any bold formatting from your replies.
    If your answer contains multiple points, display each point on a new line.
    """
)

# Start a new chat session
chat_session = model.start_chat(history=[])

# Load user data from JSON file (if needed)
with open('users.json', 'r') as f:
    users = json.load(f)

def index():
    return render_template('index.html')



@app.route('/other')
def other():
    return render_template('other_page.html')

@app.route('/')
def index():
    return render_template('chat.html')

@app.route('/chat', methods=['POST'])
def chat():
    try:
        user_input = request.json['message']
        
        # Send the user's message to the chat session
        response = chat_session.send_message(user_input)
        
        # Return the bot's response
        return jsonify({'response': response.text})

    except Exception as e:
        print(f"Error: {e}")
        return jsonify({'response': 'An error occurred. Please try again later.'}), 500

if __name__ == "__main__":
    app.run(debug=True)
